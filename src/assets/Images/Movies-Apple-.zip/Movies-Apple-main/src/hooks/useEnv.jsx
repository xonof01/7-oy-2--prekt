export const URL = import.meta.env.VITE_URL;
export const IMG_URL = import.meta.env.VITE_IMG_URL;
export const API_KEY = import.meta.env.VITE_API_KEY;
export const TOKEN = import.meta.env.VITE_TOKEN;