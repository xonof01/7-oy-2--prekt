export const PATH = {
	nowPlaying: "/", 
	popular: "/popular",
	topRated: "/top-rated",
	upcoming: "/upcoming",
	singleMovie: "/movie/:id"
}