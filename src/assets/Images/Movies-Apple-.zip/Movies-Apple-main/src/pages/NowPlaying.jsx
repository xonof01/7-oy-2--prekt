import React from 'react'
import MoviePage from '../components/MoviePage'

function NowPlaying() {
	return <MoviePage URL={"/now_playing"}/>
}

export default NowPlaying