import React from 'react'
import MoviePage from '../components/MoviePage'

function Popular() {
	return <MoviePage URL={"/popular"}/>
}

export default Popular