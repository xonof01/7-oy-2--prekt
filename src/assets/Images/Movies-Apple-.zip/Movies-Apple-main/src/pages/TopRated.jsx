import React from 'react'

function TopRated() {
	return <MoviePage URL={"/top_rated"}/>
}

export default TopRated