import React from 'react'

function Upcoming() {
	return <MoviePage URL={"/upcoming"}/>
}

export default Upcoming