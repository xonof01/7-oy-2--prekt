import NowPlaying from "./NowPlaying";
import Popular from "./Popular";
import TopRated from "./TopRated";
import Upcoming from "./Upcoming";
import SingleMovie from "./SingleMovie";

export { NowPlaying, Popular, TopRated, Upcoming, SingleMovie }